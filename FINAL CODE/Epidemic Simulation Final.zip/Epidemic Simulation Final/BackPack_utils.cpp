#include <cstdio>
#include <iostream>
#include <string>
#include <format>
#include <array>
#include <random>
#include <cmath>

#include "BackPack_Class.h"

int Backpack::getResources(){
    return resources_collected;
}

void Backpack::picked_up_resources(){
    resources_collected += 10;
}

void Backpack::generateCoords(){
    //generate new coordinates

    //since this is being called, reset the coords list
    coords_of_resources = {};

    static std::random_device rd;         // Step 1: random seed
    static std::mt19937 gen(rd());        // Step 2: engine

    std::uniform_real_distribution<double> x(-25, 25);  // Step 3: distribution for x
    std::uniform_real_distribution<double> y(-25, 25);  // Step 3: distribution for y

    //BUT FIRST, generate how many to have
    std::uniform_real_distribution<double> num(10, 20); //distribution for no. of resources can appear
    int resources_on_grid = num(gen); //how many resources to put on grid

    for (int i = 0; i < resources_on_grid; i++){
        //for each resource
        std::array<double,2> coords = {x(gen), y(gen)}; //generate the x,y coords
        coords_of_resources.push_back(coords); //add into coords list
    }
}

void Backpack::print_Coords_list(){
    std::cout << "Coordinates of all Resources present:" << std::endl;
    for (size_t i = 0; i < coords_of_resources.size(); i++){
        //print out coords of each resource
        std::cout << "{" << coords_of_resources[i][0] << "," << coords_of_resources[i][1] << "}" << std::endl;
    }
}

int Backpack::use_heal(int currenthp){
    //use 5 units of resource to hel 3 units of health
    resources_collected -= 5;
    return currenthp+3;
}

int Backpack::make_decision(double currentHealth){
    if (resources_collected > 5){ // Number of resources is greater than 5, there is enough to heal
        static std::random_device rd;         // Step 1: random seed
        static std::mt19937 gen(rd());        // Step 2: engine

        // Using Sigmoid Function
        double H = currentHealth / 100;      // Max health is 100
        double a = 10.0; //steepness
        double b = 0.46; //threshold --> more than b, probabily decrease alot, less than b, probability increase alot

        double healProbability = 1.0 / (1.0 + std::exp(a * (H - b)));
        //std::cout << "Heal Probability: " << healProbability << std::endl;
        std::bernoulli_distribution healChance(healProbability);

        if (healChance(gen)){
            //std::cout << "Decided to heal" << std::endl;
            return use_heal(currentHealth);
        }
        else{
            //std::cout << "Decided NOT to heal" << std::endl;
            return currentHealth;
        }
    }
    else{
        //std::cout << "Not enough resources to heal" << std::endl;
        return currentHealth;
    }
}


/* INITIAL MAKE DECISION FUNCTION
int Backpack::make_decision(double currenthp, double maxhp){
    //get true or false to heal or not
    if (resources_collected > 5){
        //there is enough to heal
        static std::random_device rd;         // Step 1: random seed
        static std::mt19937 gen(rd());        // Step 2: engine

        //using Sigmoid Function
        double H =  currenthp / maxhp;
        double a = 10.0; //steepness
        double b = 0.46; //threshold --> more than b, probabily decrease alot, less than b, probability increase alot

        double healProbability = 1.0 / (1.0 + std::exp(a * (H - b)));
        std::cout << "Heal Probability: " << healProbability << std::endl;
        std::bernoulli_distribution healChance(healProbability);

        if (healChance(gen)){
            std::cout << "Decided to heal" << std::endl;
            return use_heal(currenthp);
        }
        else{
            std::cout << "Decided NOT to heal" << std::endl;
            return currenthp;
        }
    }
    else{
        std::cout << "Not enough resources to heal" << std::endl;
        return currenthp;
    }
}
*/

std::vector<std::array<double,2>> Backpack::getCoords_list(){
    return coords_of_resources;
}

void Backpack::update_resources(int newR){
    resources_collected = newR;
}

void Backpack::resetBackpack(){
    resources_collected = 0;
    coords_of_resources = {};
}
