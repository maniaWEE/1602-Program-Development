#include "Survivor_Class.h"
#include "Parasite_Class.h"
#include "BackPack_Class.h"
#include "Stalker_Class.h"

#include <iostream>
#include <random>
#include <array>
#include <cmath>
#include <numbers>

#include <thread>   // for sleep_for
#include <chrono>   // for seconds


const double pi = std::numbers::pi;

// Graph axis labels thingy
std::vector<int> stepLengthGraph_win = {};
std::vector<int> distanceGraph_win = {};
std::vector<int> stepLengthGraph_lose = {};
std::vector<int> distanceGraph_lose = {};

int main()
{
    Survivor survivor; // create survivor object of class Survivor
    Stalker stalker; // create stalker object of class Stalker
    Parasite parasites; // create parasites object of class Parasite
    Backpack backpack; //create backpack object of class Backpack

    for (int i=0; i<20; i++){ // Running through 20 simulations, increasing step length by 1 each time
        survivor.resetSurvivor();
        backpack.resetBackpack();
        parasites.resetParasite();;
        stalker.resetStalker();


        backpack.generateCoords();
        parasites.generateCoords();
        bool done = false;

        while (!done) {

            if (backpack.getResources() >= 100){
                stepLengthGraph_win.push_back(survivor.getStepLength()); // Push back step length
                //std::cout << "hut completed (win)" << std::endl;
                distanceGraph_win.push_back(survivor.getTotalDistance());
                done = true;
            }
            else{
                if (survivor.getHealth() <= 0){
                    stepLengthGraph_lose.push_back(survivor.getStepLength()); // Push back step length
                    //std::cout << "survivor die" << std::endl;
                    distanceGraph_lose.push_back(survivor.getTotalDistance());
                    done = true; // end the loop
                }

                else{
                    //parasites.print_Coords_list();

                    //backpack.print_Coords_list();

                    stalker.moveStalker(); // Spawn stalker
                    //stalker.printCoords();

                    survivor.moveSurvivor(); // Spawn survivor
                    //survivor.printCoords();


                    // Check if stalker hit or not
                    if (survivor.detectHitStalker(stalker.getCoords()) == true){
                        // Resources will deplete
                        backpack.update_resources(stalker.depleteResources(backpack.getResources()));
                    }

                    //std::cout << "Before Health: " << survivor.getHealth() << std::endl;

                    // Check if stalker hit or not
                    if (survivor.detectHitParasite(parasites.getCoords_list()) == true){
                        // Reduce Health
                        survivor.setHealth(parasites.deduct_Health(survivor.getHealth()));
                        parasites.increaseNum();
                        parasites.generateCoords();
                        //std::cout << "After Health: " << survivor.getHealth() << std::endl;
                    }

                    //std::cout << "Old Resources: " << backpack.getResources() << std::endl;
                    if (survivor.detectHitResource(backpack.getCoords_list()) == true){
                        backpack.picked_up_resources();
                        backpack.generateCoords(); // Spawn new resources after collecting old resource
                        //std::cout << "New Resources: " << backpack.getResources() << std::endl;
                    }

                    // Make decision to heal or not
                    survivor.setHealth(backpack.make_decision(survivor.getHealth()));

                }
            }

        }

        survivor.increaseStepLength();
    }

    //objective but in basic prints
    std::cout << "Hut Completed Cases:" << std::endl;

    for (size_t i = 0; i < stepLengthGraph_win.size(); i++){
        std::cout << "StepLength of " << stepLengthGraph_win[i] << " resulted in " << distanceGraph_win[i] << " distance covered" << std::endl;
    }

    std::cout << "\nSurvivor Death Cases:" << std::endl;

    for (size_t i = 0; i < stepLengthGraph_lose.size(); i++){
        std::cout << "StepLength of " << stepLengthGraph_lose[i] << " resulted in " << distanceGraph_lose[i] << " distance covered" << std::endl;
    }

    /*
    std::cout << "Points to plot stepLength (win): " << stepLengthGraph_win.size() << std::endl;
    std::cout << "Points to plot distance (win): " << distanceGraph_win.size() << std::endl;
    std::cout << "Points to plot stepLength (lose): " << stepLengthGraph_lose.size() << std::endl;
    std::cout << "Points to plot distance (lose): " << distanceGraph_lose.size() << std::endl;
    */

    FILE* gnuplot = popen("C:/Progra~1/gnuplot/bin/gnuplot.exe", "w");

    if (!gnuplot){
        std::cout<<"Error opening gnuplot";
        return 1;
    }

    fprintf(gnuplot,"set multiplot layout 2,1\n");

    /* WIN DATA */
    fprintf(gnuplot,"$DataWin << EOD\n");

    for(size_t i=0;i<stepLengthGraph_win.size();i++){
        fprintf(gnuplot,"%d %d\n", stepLengthGraph_win[i], distanceGraph_win[i]);
    }

    fprintf(gnuplot,"EOD\n");

    fprintf(gnuplot,"set title 'Epidemic Win Simulation'\n");
    fprintf(gnuplot,"set xlabel 'Step Length'\n");
    fprintf(gnuplot,"set ylabel 'Distance Covered'\n");

    fprintf(gnuplot,"plot $DataWin with linespoints\n");


    /* LOSE DATA */
    fprintf(gnuplot,"$DataLose << EOD\n");

    for(size_t i=0;i<stepLengthGraph_lose.size();i++){
        fprintf(gnuplot,"%d %d\n", stepLengthGraph_lose[i], distanceGraph_lose[i]);
    }

    fprintf(gnuplot,"EOD\n");

    fprintf(gnuplot,"set title 'Epidemic Lose Simulation'\n");
    fprintf(gnuplot,"set xlabel 'Step Length'\n");
    fprintf(gnuplot,"set ylabel 'Distance Covered'\n");

    fprintf(gnuplot,"plot $DataLose with linespoints\n");

    fprintf(gnuplot,"unset multiplot\n");

    fflush(gnuplot);

    std::cin.get();

    pclose(gnuplot);

    return 0;

}



